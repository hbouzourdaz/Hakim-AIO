# Hakim Bouzourdaz — PC Care AIO

واجهة صيانة وتشخيص Windows من خلال CMD، مع قائمة ملونة وأدوات مساعدة في ملف واحد.

## ⬇️ تحميل مباشر

- **[تحميل ملف CMD](./Hakim_Bouzourdaz_PC_Care_AIO.cmd)**
- من GitHub: افتح الملف أعلاه ثم اختر **Download raw file** أو **View raw**.

> بعد نشر المستودع، يمكن استبدال رابط التحميل النسبي برابط GitHub مباشر بالشكل التالي:
>
> `https://raw.githubusercontent.com/USERNAME/REPOSITORY/main/Hakim_Bouzourdaz_PC_Care_AIO.cmd`

## المميزات

- عرض معلومات الجهاز والنظام.
- فحص ملفات النظام وأدوات إصلاح Windows.
- فحص الأقراص وتشخيص الشبكة.
- معلومات الطاقة والبطارية.
- أدوات أمان وتنظيف أساسية.
- خيار **WIN/Office Activation Scripts (MAS)**.
- خيار **Chris Titus Tech's Windows Utility**.

## التشغيل

1. نزّل ملف `.cmd` إلى جهاز Windows.
2. راجع محتوى الملف قبل التشغيل.
3. انقر عليه مرتين لتشغيله. استخدم صلاحيات المسؤول فقط عندما تتطلبها وظيفة محددة.
4. يوصى باستخدام Windows Terminal أو إصدار حديث من CMD لعرض الألوان بشكل أفضل.

## ملاحظات السلامة

- بعض الخيارات قد تستدعي أدوات خارجية أو تجلب سكريبتات من الإنترنت.
- افحص أي سكريبت خارجي قبل تشغيله، ولا تشغّل أوامر بعيدة بصلاحيات المسؤول دون مراجعة.
- لا تضمن معلومات صحة الأقراص أو النظام سلامة العتاد بشكل قطعي.
- هذا المشروع غير مرتبط رسميًا بشركة Microsoft أو بمطوري الأدوات الخارجية المذكورة.

## معلومات الملف

- المطوّر: **Hakim Bouzourdaz**
- الإصدار المقترح: **v1.0.0**
- اسم الملف: `Hakim_Bouzourdaz_PC_Care_AIO.cmd`
- SHA-256: `6b55a78a69e5fc72c11cc153e05260327ddb3208abe514994578932ed3041732`

## GitHub Release

عند إنشاء إصدار جديد في GitHub، استخدم الوسم `v1.0.0` وارفع ملف `Hakim_Bouzourdaz_PC_Care_AIO.cmd` ضمن **Release assets**. بعد النشر، ضع رابط الإصدار المباشر هنا:

`https://github.com/USERNAME/REPOSITORY/releases/latest`

